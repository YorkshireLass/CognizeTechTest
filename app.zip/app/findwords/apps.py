from django.apps import AppConfig


class FindwordsConfig(AppConfig):
    name = 'findwords'
